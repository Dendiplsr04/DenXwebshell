Shell backdoor adalah program atau skrip yang digunakan oleh peretas untuk mendapatkan akses jarak jauh ke sistem yang telah mereka kompromikan. Shell backdoor memungkinkan peretas untuk menjalankan perintah sistem, mengakses file, dan menjalankan operasi lain seolah-olah mereka adalah pengguna yang sah di sistem tersebut.

Berikut beberapa file backdoor yang dapat anda gunakan 

Mini Shell open source code
nama file : adm.php
Shell yang versi kecil cocok buat web yang ga bisa upload backdoor di atas 200kb 

Mini Shell aspx tebus semua server windows 
nama file: akmal.aspx
cocok untuk web yang bisa type aspx saja dan juga shell udah support semua jenis type asp.net jadinya bisa tembus sarver apa saja tanpa ada error.

filemanager Backdoor all bypas open source code
nama file : filemanager.php
Filemanager tampilan seperti hal nya manager lengkap dengan ada nya terminal di dalamnya serta fitur lain

wso all bypas open source code(  default pw 123 )
nama file : wso.php
Wso Shell yang lumayan banyak mempunyai fitur di tambah dengan ada kemanan dari pakai password sebelum shell bisa di gunakan.

mini Shell anti 403 dan 0kb file.
nama file : ali.php
Shell tersebut cocok buat sarver yang kadang mengubah Shell yang kita upload jadi 0kb dalam beberapa menit atau 0kb langsung 
Shell mempunyai terminal dan kekurangan Shell tersebut tidak ada nya edit file secara langsung/ sarver.

alpha backdoor modifikasi 
nama file : Alfa.php
shell alpha yang udah di modif untuk di perbanyak fitur

gecko backdoor anti 403
nama file: gecko.php
Shell yang sering di pakai karena tembus semua website dan mempunyai banyak fitur
